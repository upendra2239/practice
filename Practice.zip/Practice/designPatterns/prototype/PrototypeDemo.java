package designPatterns.prototype;

import java.util.ArrayList;
import java.util.List;

public class PrototypeDemo {

	public static void main(String[] args) {
		String sql = "select * from movies where title =?";
		
		List<String> parameters = new ArrayList<>();
		
		parameters.add("Star wars");
		Record record = new Record();
		
		Statement firstStatement = new Statement(sql, parameters, record);
		
		System.out.println(firstStatement.getSql());
		System.out.println(firstStatement.getParameters());
		System.out.println(firstStatement.getRecord());
		
		Statement anotherStatement = firstStatement.clone();
		
		System.out.println(anotherStatement.getSql());
		System.out.println(anotherStatement.getParameters());
		System.out.println(anotherStatement.getRecord());
		
	}
}


