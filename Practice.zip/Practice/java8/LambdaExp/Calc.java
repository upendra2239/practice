package java8.LambdaExp;

public class Calc {

	interface Add{
		int sum(int a, int b);
	}
	interface Sub{
		int subt(int a, int b);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Add add = (x,y)-> x+y;
		Sub sub = (x,y)-> x - y;
				
		System.out.println(add.sum(6, 5));
		System.out.println(sub.subt(6, 5));

	}

}
