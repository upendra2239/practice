package java8.LambdaExp;

public class Threads {

	public static void main(String[] args) {


		Runnable myThread = ()->{
			Thread.currentThread().setName("my Thread");
			System.out.println(Thread.currentThread().getName());
		};
		Thread run = new Thread(myThread);
		run.start();
	}

}
