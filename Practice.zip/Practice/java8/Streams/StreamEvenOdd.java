package java8.Streams;

import java.util.Arrays;
import java.util.List;

public class StreamEvenOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = Arrays.asList(1,6,8,3,9,5);
		list.stream().filter(x->x%2==0).forEach(System.out::println);
	}

}
