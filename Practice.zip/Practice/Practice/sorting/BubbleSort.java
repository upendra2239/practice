package sorting;

/*in place algorithm
 * O(n^2) time complexity - quadratic
 * Ex: it takes 100 steps to sort 10 items
 * 10000 steps to sort 100 items etc.
 * Algorithm degrades quickly
 */
public class BubbleSort {

	public static void main(String[] args) {
		
		int[] intArray = {20,35,-15,7,55,1,-22};
		
		int n = intArray.length;
		
		for(int i=0; i< n-1; i++) {
			for(int j =0; j < n-i-1; j++) {
				if(intArray[j] > intArray[j+1]) {
					int temp = intArray[j];
					intArray[j] = intArray[j+1];
					intArray[j+1] = temp;
				}
			}
		}
		
		for(int num: intArray) {
			System.out.println(num);
		}
		
	}
	
	

}
