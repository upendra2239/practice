package designPatterns.factory;

public interface OS {

	void spec();
}
