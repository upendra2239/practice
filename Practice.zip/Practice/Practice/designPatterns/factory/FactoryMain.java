package designPatterns.factory;

public class FactoryMain {

	public static void main(String[] args) {

		OperatingSystemFactory osf = new OperatingSystemFactory();
		OS obj2 = osf.getInstance("fhdjfg");
		obj2.spec();
		
		OS obj1 = new Windows();
		obj1.spec();
	}

}
