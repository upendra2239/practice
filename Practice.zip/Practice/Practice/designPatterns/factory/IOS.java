package designPatterns.factory;

public class IOS implements OS{

	public void spec() {
		System.out.println("Most secure OS");
	}
}
