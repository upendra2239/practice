package designPatterns.prototype;

public class Record {

}
