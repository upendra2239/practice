package designPatterns.builder;

//Demo exposed setters and drawbacks of it
//Demo telescoping constructors
//create builder and example
public class BuilderDemo {

	public static void main(String[] args) {

		StringBuilder builder = new StringBuilder();
		builder.append("This is an example ");
		
		builder.append("of the builder pattern. ");
		builder.append("It has methods to append ");
		builder.append("almost anything we want to a string. ");
		
		builder.append(42);
		
		System.out.println(builder.toString());
		
	}

}
