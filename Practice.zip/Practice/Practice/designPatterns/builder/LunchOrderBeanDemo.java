package designPatterns.builder;

public class LunchOrderBeanDemo {

	public static void main(String[] args) {

		LunchOrderBean lunchOrderDemo = new LunchOrderBean("Wheat","Lettuce","Musturd","Chicken");
		
		/*
		 * lunchOrderDemo.setBread("Wheat"); lunchOrderDemo.setCondiments("Lettuce");
		 * lunchOrderDemo.setDressing("Musturd"); lunchOrderDemo.setMeat("Chicken");
		 */
		System.out.println(lunchOrderDemo.getBread());
		System.out.println(lunchOrderDemo.getCondiments());
		System.out.println(lunchOrderDemo.getDressing());
		System.out.println(lunchOrderDemo.getMeat());
	}

}
