package designPatterns.builder;

public class Shop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Phone p = new Phone("Android",2,"Qualcomm",5.5,3100);
		
		System.out.println(p);
		
		Phone p1 = new PhoneBuilder().setOs("IOS").setProcessor("M1").setRam(4).setBattery(4000).getPhone();
		
		System.out.println(p1);
		
	}

	
}
