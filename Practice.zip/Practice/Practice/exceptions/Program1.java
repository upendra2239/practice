package exceptions;

//Arithmetic Exception program
public class Program1 {

	public static void main(String[] args) {

		method2();
		
	}
	
	/*stacktrace
	 * Exception name- java.lang.ArithmeticException
	 * Exception message - / by zero
	 * which line
	 * methods info
	*/
	
	public static void method2() {
		method1();
	}
	public static void method1() {
		System.out.println("program execution start");
		
		int a = 4;
		int b = 0;
		int sum=0;
		try {
			sum = a/b;
		} catch (ArithmeticException ae) {
			
			ae.printStackTrace();
		}finally {
			System.out.println("finally block");
		}
		
		
		System.out.println("output is zero: "+sum);
		
		System.out.println("program execution end");
	}

}
