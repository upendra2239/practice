package basic;

public class StaticClass {

	static int n = 1;
	
	static void message() {
		System.out.println("Hello");
	}
}
