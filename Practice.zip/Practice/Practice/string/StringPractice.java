package string;

public class StringPractice {

	public static void main(String[] args) {

		
	}

}
