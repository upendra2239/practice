package string;

public class StringSubstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "Get the future you want";
		
		System.out.println(s.substring(4));
		
		//end index is not included
		System.out.println(s.substring(4, 14));
	}

}
