package string;

public class StringReverseStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Hello";
		
		String str1 = new StringBuilder(str).reverse().toString();
		System.out.println(str1);

	}

}
